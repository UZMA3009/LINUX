#!/bin/bash

echo "Enter Your Name "
read Name
echo "Welcome $Name"
