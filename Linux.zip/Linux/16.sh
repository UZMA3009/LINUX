#!/bin/bash

function myFun()
{
    echo "i created myFun"
}
myFun
