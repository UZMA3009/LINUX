#!/bin/bash

echo "Sum of Two Numbers"
((Sum=10+20))
echo $Sum  # $Sum represents Variable
