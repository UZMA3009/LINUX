#!/bin/bash

: '
Use of Multi Line Commet using.
All are Comments;
'


echo "Multiplication of Two Numbers"
((Mul=10*20))
echo $Mul 
