#!/bin/bash

echo "Hello world!"
echo -n "Printing Text without New Line"
echo -e "\nRemoving \t Backslash \t characters"
