#!/bin/bash

echo "Enter First Number"
read num1

echo "Enter Second Number"
read num2

((sum=num1+num2))
echo "Sum of Numbers = $sum"
