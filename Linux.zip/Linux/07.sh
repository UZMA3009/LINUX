#!/bin/bash

num=10
if [ $num -eq 10 ];
then
echo "It is Equal to 10"
else
echo "It is Not Equal to 10"
fi
