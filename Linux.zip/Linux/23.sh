#!/bin/bash

echo “Wait for 5 seconds”
sleep 5
echo “Completed”
